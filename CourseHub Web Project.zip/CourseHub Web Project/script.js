
/* =========================
   Home Page
========================= */

// Welcome message
const siteName = "CourseHub";
console.log(`Welcome to ${siteName}! Ready to learn?`);

// Card interaction
const cards = document.querySelectorAll('.card');

cards.forEach(card => {
    card.addEventListener('click', function () {

        const category = this.querySelector('p').innerText;

        alert(`Course: ${category}`);

    });
});
	





/* =========================
   Course Page
========================= */

function filterCourses(category) {

    const allCourses = document.querySelectorAll('.course-card');

    allCourses.forEach(course => {

        if (category === 'all' || course.classList.contains(category)) {
            course.style.display = "block";
        } else {
            course.style.display = "none";
        }

    });

    const allButtons = document.querySelectorAll('.course-tags button');

    allButtons.forEach(btn => {

        const btnText = btn.textContent.toLowerCase();

        if (
            btnText.includes(category) ||
            (category === 'all' && btnText === 'all')
        ) {

            btn.style.backgroundColor = "#7c3aed";
            btn.style.color = "white";
            btn.style.transform = "scale(1.1)";
            btn.style.border = "none";

        } else {

            btn.style.backgroundColor = "transparent";
            btn.style.color = "white";
            btn.style.border = "1px solid #7c3aed";
            btn.style.transform = "scale(1.0)";
        }

    });
}

const sortSelect = document.getElementById('sort');

if (sortSelect) {

    sortSelect.addEventListener('change', (e) => {
        filterCourses(e.target.value);
    });

}


/* =========================
   FreeHub Page
========================= */

const excelCard = document.querySelector('.excel-card');
const pythonCard = document.querySelector('.python-card');
const webCard = document.querySelector('.web-card');

function filterSelection(category) {

    if (!excelCard || !pythonCard || !webCard) return;

    switch (category) {

        case "all":

            excelCard.style.display = "block";
            pythonCard.style.display = "block";
            webCard.style.display = "block";

            break;

        case "excel":

            excelCard.style.display = "block";
            pythonCard.style.display = "none";
            webCard.style.display = "none";

            break;

        case "python":

            excelCard.style.display = "none";
            pythonCard.style.display = "block";
            webCard.style.display = "none";

            break;

        case "web":

            excelCard.style.display = "none";
            pythonCard.style.display = "none";
            webCard.style.display = "block";

            break;

        default:

            excelCard.style.display = "block";
            pythonCard.style.display = "block";
            webCard.style.display = "block";
    }
}


/* FreeHub Buttons */

const btnAll = document.getElementById("btn-all");
const btnExcel = document.getElementById("btn-excel");
const btnPython = document.getElementById("btn-python");
const btnWeb = document.getElementById("btn-web");

if (btnAll) {
    btnAll.onclick = function () {
        filterSelection('all');
    };
}

if (btnExcel) {
    btnExcel.onclick = function () {
        filterSelection('excel');
    };
}

if (btnPython) {
    btnPython.onclick = function () {
        filterSelection('python');
    };
}

if (btnWeb) {
    btnWeb.onclick = function () {
        filterSelection('web');
    };
}


/* =========================
   Contact Page
========================= */

function validateName(name) {

    if (name.trim() === '') return "Your name is required";

    if (!isNaN(name)) return "Number is not allowed";

    return '';
}


function validateEmail(email) {

    if (email === '') return "Your email is required";

    const emailFormat = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!emailFormat.test(email))
        return 'Incorrect email format';

    if (email.length < 4)
        return "The email is very short , try again";

    return '';
}


function validateTopic(topic) {

    if (topic==='') return "Topic is required";
	
	if (topic.length < 4)
        return "The topic is short , minimum letters are 4";

    if (topic === '')
        return "Write your topic";

    if (/^[^a-zA-Z]/.test(topic))
        return "Only start with letters";

    return '';
}


function validateDescribtion(mess) {

    if (mess === '')
        return "Message box is required";

    if (mess.length < 10)
        return "Your massage is very short ,the minimum letters are 10";

    return '';
}


function finalResult(elementId, errorNote) {

    const target = document.getElementById(elementId);

    if (!target) return;

    if (errorNote === '') {

        target.textContent = '✔️ Accepted';
        target.className = 'safe';

    } else {

        target.textContent = '⚠️ ' + errorNote;
        target.className = 'wrong';
    }
}


function validateAll() {

    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const topic = document.getElementById('topic').value;
    const mess = document.getElementById('mess').value;

    const nameFail = validateName(name);
    const emailFail = validateEmail(email);
    const topicFail = validateTopic(topic);
    const messFail = validateDescribtion(mess);
	
	
	 if (!nameFail && !emailFail && !topicFail && !messFail ) {
        alert('✅ Form submitted successfully!');
	 }

    finalResult('urName', nameFail);
    finalResult('urEmail', emailFail);
    finalResult('topicTxt', topicFail);
    finalResult('discribtion', messFail);
}



	
	
	 
	  